<?php
require_once 'connect.php';

session_start();
if($_SESSION['UserID'] == "")
{
  echo "Please Login!";
  exit();
}

if($_SESSION['Status'] != "USER")
{
  echo "This page for User only!";
  exit();
}	

$strSQL = "SELECT * FROM member WHERE UserID = '".$_SESSION['UserID']."' ";
$objQuery = mysqli_query($conn, $strSQL);
$objResult = mysqli_fetch_array($objQuery);


$sql_sensor = "SELECT DISTINCT sensor FROM sensordata_nbi;";
$query_sensor = mysqli_query($conn, $sql_sensor);


$sql_statuscar = "SELECT DISTINCT statuscar FROM sensordata_nbi;";
$query_statuscar = mysqli_query($conn, $sql_statuscar);

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title>GPS-Tracking</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png" />
    <link rel="stylesheet" href="plugins/themefisher-font.v-2/style.css">
    <link rel="stylesheet" href="plugins/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="plugins/slick-carousel/slick/slick.css">
    <link rel="stylesheet" href="plugins/slick-carousel/slick/slick-theme.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

    <!-- เรียกใช้ javascript สำหรับ export ไฟล์ excel  -->
    <script src="https://unpkg.com/xlsx/dist/xlsx.full.min.js"></script>
    <script src="https://unpkg.com/file-saver@1.3.3/FileSaver.js"></script>

    <!-- Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@100;200&display=swap" rel="stylesheet">


    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


    <style>
    body {
        font-family: 'Sarabun', sans-serif;
    }

    #map {
        width: 100%;
        height: 550px;
    }

    /*.datatable{
        margin-right: 25px;
        margin-left: 25px;
    }*/
    .borderless {
        border: none;
    }
    </style>
</head>

<body>


    <section class="header  navigation">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-expand-lg">
                        <a class="navbar-brand" href="index.html"><img src="images/kmutt.png" class="img-responsive"
                                alt="logo"></a>
                        <a class="navbar-brand" href="index.html"><img src="images/nrct.png" class="img-responsive"
                                alt="logo"></a>
                        <a class="navbar-brand" href="index.html"><img src="images/department_of_health.png"
                                class="img-responsive" alt="logo"></a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse"
                            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="tf-ion-android-menu"></span>
                        </button>
                    </nav>
                </div>
            </div>
        </div>
    </section>


    <section class="counter section-sm">
        <div class="container">
            <div class="card">
                <div class="p-3 mb-2 bg-light text-dark">
                    <div class="card-body">
                        <p><b>ชื่อผู้ใช้งาน:</b> <?php echo $objResult["Username"];?></p>
                        <p><b>ชื่อ-นามสกุล:</b> <?php echo $objResult["Name"];?></p>
                        <p><b>หน่วยงาน:</b> บริษัท โชติฐกรณ์พิบูลย์ จำกัด</p>
                        <button type="button" class="btn btn-light"><a href="logout.php">ออกจากระบบ</a></button>
                    </div>
                </div>
            </div>

            <br>
            <a href="user_page2.php"><button type="button" class="btn btn-primary">กลับหน้าหลัก</button></a>
            <br><br>

            <div class="datatable">
                <?php
                    $sql = "SELECT * FROM sensordata_nbi WHERE sensor ='".$_GET["sensor"]."' AND statuscar ='".$_GET["statuscar"]."' ORDER BY ID DESC LIMIT 50";

                        echo '<table cellspacing="5" cellpadding="5" class="table table-striped table-hover">
                            <tr>
                                <th>ลำดับ</th>
                                <th>วัน/เวลา</th>
                                <th>ทะเบียนรถ</th>
                                <th>ละติจูด</th>
                                <th>ลองจิจูด</th>
                                <th>ความเร็ว</th>
                                <th>สถานะ</th>
                                <th>รายละเอียด</th>
                            </tr>';
                            
                        if ($result = $conn->query($sql)) {
                            while ($row = $result->fetch_assoc()) {
                            $row_id = $row["ID"];
                            $row_reading_time = $row["reading_time"];
                            $row_sensor = $row["sensor"];
                            $row_lat_str = $row["lat_str"];
                            $row_lng_str = $row["lng_str"];
                            $row_speedcar = $row["speedcar"];
                            $row_statuscar = $row["statuscar"];
                            $row_reading_time = date("Y-m-d H:i:s", strtotime("$row_reading_time + 7 hours"));
                            
                            echo '<tr>
                                    <td>' . $row_id . '</td>
                                    <td>' . $row_reading_time . '</td>
                                    <td>' . $row_sensor . '</td>
                                    <td>' . $row_lat_str . '</td>
                                    <td>' . $row_lng_str . '</td>
                                    <td>' . $row_speedcar . '</td>
                                    <td>' . $row_statuscar . '</td>
                                    <td><a href="detail.php?sensor='. $row_sensor .'&lat_str=' . $row_lat_str . '&lng_str=' . $row_lng_str . '&status_str='. $row_statuscar . '&speed_str=' . $row_speedcar . '&time_str=' . $row_reading_time . '" target="_blank"> รายละเอียด </a></td>
                                </tr>';
                            }
                            $result->free();
                        }
                        $conn->close();
      ?>

            </div>
        </div>
    </section>

    <script src="plugins/jquery/dist/jquery.min.js"></script>
    <script src="plugins/bootstrap/dist/js/popper.min.js"></script>
    <script src="plugins/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="plugins/slick-carousel/slick/slick.min.js"></script>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
    <script src="plugins/smooth-scroll/dist/js/smooth-scroll.min.js"></script>
    <script src="js/script.js"></script>
    <script src="assets/jquery.min.js"></script>
    <script src="assets/script.js"></script>
    <script>
    function ExcelReport() //function สำหรับสร้าง ไฟล์ excel จากตาราง
    {
        var sheet_name = "excel_sheet"; /* กำหหนดชื่อ sheet ให้กับ excel โดยต้องไม่เกิน 31 ตัวอักษร */
        var elt = document.getElementById(
            'myTable'); /*กำหนดสร้างไฟล์ excel จาก table element ที่มี id ชื่อว่า myTable*/

        /*------สร้างไฟล์ excel------*/
        var wb = XLSX.utils.table_to_book(elt, {
            sheet: sheet_name
        });
        XLSX.writeFile(wb, 'report.xlsx'); //Download ไฟล์ excel จากตาราง html โดยใช้ชื่อว่า report.xlsx
    }
    </script>
</body>

</html>