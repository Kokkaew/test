

<?
// Load the database configuration file 
require_once 'connect.php';

session_start();
if($_SESSION['UserID'] == "")
{
  echo "Please Login!";
  exit();
}

if($_SESSION['Status'] != "ADMIN")
{
  echo "This page for Admin only!";
  exit();
}	

ini_set('memory_limit','-1'); // enabled the full memory available.

// Fetch records from database 
//$sql = "SELECT * FROM sensordata ORDER BY ID DESC;";
$sql = "SELECT * FROM sensordata UNION SELECT * FROM `sensordata_nbi` ORDER BY ID DESC;";
$query = mysqli_query($conn, $sql);
mysqli_set_charset($conn,"utf8"); 


if($query->num_rows > 0){ 
    $delimiter = ","; 
    $filename = "members-data_" . date('Y-m-d') . ".csv"; 
     
    // Create a file pointer 
    $f = fopen('php://memory', 'rw+'); 
     
    // Set column headers 
    $fields = array('ID', 'Vehicle registration', 'Latitude', 'Longitude', 'Status', 'Date/Time', 'Speed'); 
    fputcsv($f, $fields, $delimiter); 
     
    // Output each row of the data, format line as csv and write to file pointer 
    while($row = $query->fetch_assoc()){ 
        $lineData = array($row['ID'], $row['sensor'], $row['lat_str'], $row['lng_str'], $row['statuscar'], $row['reading_time'], $row['speedcar']); 
        fputcsv($f, $lineData, $delimiter); 
    } 
     
    // Move back to beginning of file 
    fseek($f, 0); 
     
    // Set headers to download file rather than displayed 
    header('Content-Type: text/html; charset=');
    header('Content-Type: text/csv'); 
    header('Content-Disposition: attachment; filename="' . $filename . '";'); 
     
    //output all remaining data on a file pointer 
    fpassthru($f); 
} 
exit; 
 
?>
