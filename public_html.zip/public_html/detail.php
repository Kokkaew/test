<?php
require_once 'connect.php';
/*
session_start();
if($_SESSION['UserID'] == "")
{
  echo "Please Login!";
  exit();
}

if($_SESSION['Status'] != "USER")
{
  echo "This page for User only!";
  exit();
}	

$strSQL = "SELECT * FROM member WHERE UserID = '".$_SESSION['UserID']."' ";
$objQuery = mysqli_query($conn, $strSQL);
$objResult = mysqli_fetch_array($objQuery);*/


$sql_sensor = "SELECT DISTINCT sensor FROM sensordata ORDER BY sensor DESC;";
$query_sensor = mysqli_query($conn, $sql_sensor);

$sql_sensor_count = "SELECT COUNT(DISTINCT sensor) FROM sensordata;";
$query_sensor_count = mysqli_query($conn, $sql_sensor_count);

$sql_sensorID_count = "SELECT COUNT(ID) FROM sensordata";
$query_sensorID_count = mysqli_query($conn, $sql_sensorID_count);


$sql_statuscar = "SELECT DISTINCT statuscar FROM sensordata;";
$query_statuscar = mysqli_query($conn, $sql_statuscar);

$sql = "SELECT * FROM sensordata";
$query = mysqli_query($conn, $sql);

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="assets/bootstrap.min.css" rel="stylesheet">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>GPS-Tracking</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png" />
    <link rel="stylesheet" href="plugins/themefisher-font.v-2/style.css">
    <link rel="stylesheet" href="plugins/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="plugins/slick-carousel/slick/slick.css">
    <link rel="stylesheet" href="plugins/slick-carousel/slick/slick-theme.css">
    <link rel="stylesheet" href="css/style.css">

    <style>
    #map {
        width: 100%;
        height: 600px;
    }

    .datatable {
        margin-right: 25px;
        margin-left: 25px;
    }

    .text-left {
        text-align: left !important;
    }
    </style>

</head>

<body onload="init();">
    <div id="preloader">
        <div class="preloader">
            <div class="sk-circle1 sk-child"></div>
            <div class="sk-circle2 sk-child"></div>
            <div class="sk-circle3 sk-child"></div>
            <div class="sk-circle4 sk-child"></div>
            <div class="sk-circle5 sk-child"></div>
            <div class="sk-circle6 sk-child"></div>
            <div class="sk-circle7 sk-child"></div>
            <div class="sk-circle8 sk-child"></div>
            <div class="sk-circle9 sk-child"></div>
            <div class="sk-circle10 sk-child"></div>
            <div class="sk-circle11 sk-child"></div>
            <div class="sk-circle12 sk-child"></div>
        </div>
    </div>

    <section class="header  navigation">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-expand-lg">
                        <a class="navbar-brand" href="index.html"><img src="images/kmutt-th.png" class="img-responsive"
                                alt="logo"></a>
                        <a class="navbar-brand" href="index.html"><img src="images/nrct-logo.png" class="img-responsive"
                                alt="logo"></a>
                        <a class="navbar-brand" href="index.html"><img src="images/department_of_health.png"
                                class="img-responsive" alt="logo"></a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse"
                            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="tf-ion-android-menu"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item active">
                                    <!--<a class="nav-link" href="index.php">หน้าแรก <span
                                            class="sr-only">(current)</span></a>-->
                                </li>
                                <li class="nav-item">
                                    <!--<a class="nav-link" href="about.php">ข้อมูลโครงการ</a>-->
                                </li>
                                <li class="nav-item">
                                    <!--<a class="nav-link" href="contact.php">ติดต่อเรา</a>-->
                                </li>
                            </ul>
                        </div>
                        <div class="topnav">
                            <div class="login-container">
                                <a href="logout.php">
                                    <img src="images/login/log-out.png" class="img-responsive" alt=""></a>
                            </div>
                        </div>
                    </nav>

                </div>
            </div>
        </div>
    </section>


    <br>

    <section class="counter section-sm">
        <div class="container">
            <div class="row">
                <div class="col-8">
                    <div id="map"></div>
                    <script>
                    function initMap() {
                        const myLatLng = {
                            lat: <?php echo $_GET['lat_str']; ?>,
                            lng: <?php echo $_GET['lng_str'];?>
                        };
                        const map = new google.maps.Map(document.getElementById("map"), {
                            zoom: 18,
                            center: myLatLng,
                            mapTypeId: 'satellite'
                        });

                        new google.maps.Marker({
                            position: myLatLng,
                            map,
                        });
                    }

                    window.initMap = initMap;
                    </script>
                </div>
                <div class="col-4">

                    <h4>รายละเอียด:</h4>
                    <hr>
                    <p>ทะเบียนรถ: <?php echo $_GET['sensor'];?></p>
                    <p>สถานะ: <?php echo $_GET['status_str'];?></p>
                    <p>ความเร็ว (กม/ชม): <?php echo $_GET['speed_str'];?></p>
                    <p>ตำแหน่งละติจูด: <?php echo $_GET['lat_str']; ?></p>
                    <p>ตำแหน่งลองจิจูด: <?php echo $_GET['lng_str'];?></p>
                    <p>วัน/เวลา: <?php echo $_GET['time_str'];?></p>
                    <!--<button type="button" class="btn btn-success">ดาวน์โหลด</button>-->
                </div>

            </div>
        </div>
    </section>

    <script src="plugins/jquery/dist/jquery.min.js"></script>
    <script src="plugins/bootstrap/dist/js/popper.min.js"></script>
    <script src="plugins/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="plugins/slick-carousel/slick/slick.min.js"></script>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
    <script src="plugins/smooth-scroll/dist/js/smooth-scroll.min.js"></script>
    <script src="js/script.js"></script>
    <script src="assets/jquery.min.js"></script>
    <script src="assets/script.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB0i77Mj0pOX0URlGv7Ska295R9ua0ifIk&callback=initMap"
        async defer></script>
</body>

</html>