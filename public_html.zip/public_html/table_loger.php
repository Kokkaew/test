<?php
require_once 'connect.php';

// Check connection
if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
}


$sql_rm = "DELETE FROM `sensordata` WHERE `lat_str` = ''";
if ($conn->query($sql_rm) === TRUE) {echo "";} 
else { 	echo "";}

$sql_stop = "UPDATE `sensordata` SET `statuscar`='Stop' WHERE speedcar < 1";
if ($conn->query($sql_stop) === TRUE) {echo "";} 
else {echo "";}

$sql_run = "UPDATE `sensordata` SET `statuscar`='Runing' WHERE speedcar >= 1";
if ($conn->query($sql_run) === TRUE) {echo "";} 
else {echo "";}

/*
$sql_2544 = "UPDATE `sensordata` SET `sensor` = REPLACE(`sensor`, '84-2544', 'GPS_CAR01')";
if ($conn->query($sql_2544) === TRUE) {echo "";} 
else {echo "";}

$sql_4421 = "UPDATE `sensordata` SET `sensor` = REPLACE(`sensor`, '84-4421', 'GPS_CAR02')";
if ($conn->query($sql_4421) === TRUE) {echo "";} 
else {echo "";}

$sql_2424 = "UPDATE `sensordata` SET `sensor` = REPLACE(`sensor`, '84-2424', 'GPS_CAR03')";
if ($conn->query($sql_2424) === TRUE) {echo "";} 
else {echo "";}

$sql_5855 = "UPDATE `sensordata` SET `sensor` = REPLACE(`sensor`, 'บล-5855', 'GPS_CAR04')";
if ($conn->query($sql_5855) === TRUE) {echo "";} 
else {echo "";}

$sql_3633 = "UPDATE `sensordata` SET `sensor` = REPLACE(`sensor`, '84-3633', 'GPS_CAR05')";
if ($conn->query($sql_3633) === TRUE) {echo "";} 
else {echo "";}

$sql_4061 = "UPDATE `sensordata` SET `sensor` = REPLACE(`sensor`, '84-4061', 'GPS_CAR07')";
if ($conn->query($sql_4061) === TRUE) {echo "";} 
else {echo "";}

$sql_3633 = "UPDATE `sensordata` SET `sensor` = REPLACE(`sensor`, '84-3633', 'GPS_CAR06')";
if ($conn->query($sql_3633) === TRUE) {echo "";} 
else {echo "";}/*



$sql = "SELECT id, sensor, lat_str, lng_str, speedcar, statuscar, reading_time 
		FROM sensordata 
		ORDER BY id DESC LIMIT 100"; 
		
//$bbdate = date("d-m-Y",strtotime("-1 day"));
//$sqlnews = "SELECT * FROM news WHERE date >= '$bbdate'-1 and date = '$bbdate'  ORDER BY  RAND() LIMIT 10";

echo '<table cellspacing="5" cellpadding="5" class="table table-striped table-hover">
	   <tr> 
		<th>ลำดับ</th> 
		<th>วัน/เวลา</th> 
		<th>ทะเบียนรถ</thh>
		<th>ละติจูด</th> 
		<th>ลองจิจูด</th> 
		<th>ความเร็ว</th>
		<th>สถานะ</th>
		<th>รายละเอียด</th>
	  </tr>';
 
if ($result = $conn->query($sql)) {
	while ($row = $result->fetch_assoc()) {
		$row_id = $row["id"];
		$row_reading_time = $row["reading_time"];
		$row_sensor = $row["sensor"];
		$row_lat_str = $row["lat_str"];
		$row_lng_str = $row["lng_str"];
		$row_speedcar = $row["speedcar"]; 
		$row_statuscar = $row["statuscar"];
		
		
		$row_reading_time = date("Y-m-d H:i:s", strtotime("$row_reading_time + 7 hours")); 
	

		echo '<tr> 
				<td>' . $row_id . '</td> 
				<td>' . $row_reading_time . '</td> 
				<td>' . $row_sensor . '</td>
				<td>' . $row_lat_str . '</td> 
				<td>' . $row_lng_str . '</td> 
				<td>' . $row_speedcar . '</td>
				<td>' . $row_statuscar . '</td>
				<td><a href="detail.php?sensor='. $row_sensor .'&lat_str=' . $row_lat_str . '&lng_str=' . $row_lng_str . '&status_str='. $row_statuscar . '&speed_str=' . $row_speedcar . '&time_str=' . $row_reading_time . '" target="_blank"> รายละเอียด </a></td>
			  </tr>';
	}
	$result->free();
}

$conn->close();
?>

