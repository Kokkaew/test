<?php
include( 'connect.php' );
?>

<!DOCTYPE html>
<html lang='en'>

<head>
    <meta charset='UTF-8'>
    <!--<meta http-equiv = 'refresh' content = '1' >-->
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <meta http-equiv='X-UA-Compatible' content='ie=edge'>
    <title>GPS Tracking</title>
    <link href='assets/bootstrap.min.css' rel='stylesheet'>
    <meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>

    <title>GPS-Tracking</title>

    <!-- Mobile Specific Meta -->
    <meta name='viewport' content='width=device-width, initial-scale=1'>

    <!-- Favicon -->
    <link rel='shortcut icon' type='image/x-icon' href='img/favicon.png' />

    <!-- CSS -->
    <!-- Themefisher Icon font -->
    <link rel='stylesheet' href='plugins/themefisher-font.v-2/style.css'>

    <!-- bootstrap.min css -->
    <link rel='stylesheet' href='plugins/bootstrap/dist/css/bootstrap.min.css'>

    <!-- Slick Carousel -->
    <link rel='stylesheet' href='plugins/slick-carousel/slick/slick.css'>
    <link rel='stylesheet' href='plugins/slick-carousel/slick/slick-theme.css'>

    <!-- Main Stylesheet -->
    <link rel='stylesheet' href='css/style.css'>

    <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js'></script>

    <style>
    .table {
        width: 100%;
        margin-bottom: 0.2rem;
        color: #212529;
    }
    </style>

</head>

<body>

    <?php

$sql_icon = "UPDATE `sensordata_nbi` SET `icon`='track-red.png'";
if ( $conn->query( $sql_icon ) === TRUE ) {
    echo '';
} else {
    echo '';
}

$sql_agency = "UPDATE `sensordata_nbi` SET `agency`='เทศบาลเมืองสุพรรณบุรี'";
if ( $conn->query( $sql_agency ) === TRUE ) {
    echo '';
} else {
    echo '';
}

$strSQL = 'SELECT * FROM `sensordata` WHERE ID IN ( SELECT MAX(ID) FROM `sensordata` GROUP BY sensor ) UNION SELECT * FROM `sensordata_nbi` WHERE ID IN ( SELECT MAX(ID) FROM `sensordata_nbi` GROUP BY sensor ) ORDER BY `reading_time` DESC ';

$result = $conn->query( $strSQL );

if ( $result->num_rows > 0 ) {
    while ( $row = $result->fetch_assoc() ) {
        $row_id = $row[ 'ID' ];
        $row_reading_time = $row[ 'reading_time' ];
        $row_sensor = $row[ 'sensor' ];
        $row_lat_str = $row[ 'lat_str' ];
        $row_lng_str = $row[ 'lng_str' ];
        $row_statuscar = $row[ 'statuscar' ];
        $row_speedcar = $row[ 'speedcar' ];
        $row_agency = $row[ 'agency' ];
        $row_icon = $row[ 'icon' ];

        $row_reading_time = date( 'Y-m-d H:i:s', strtotime( "$row_reading_time + 7 hours" ) );

        echo '<table cellspacing="5" cellpadding="5" class="table table-striped table-hover" style="font-size: 11px">'.
        '<tr>'.
        '<td>' .
        '<img src="images/'.$row_icon.'" class="img-fluid" alt="Responsive image">'.
        '</td>'.
        '<td>'.
        '<b>หน่วยงาน: </b>' .$row_agency.'<br>'.
        '<b>ทะเบียนรถ: </b>' . $row_sensor . '<br>'.
        '<b>สถานะ: </b><span style="color:green"> '. $row_statuscar .' </span><br>'.
        '<b>วันที่/เวลา: </b><span style="color:green"> '. $row_reading_time .' </span><br>'.
        '<td>'.
        '<td>'.
        '<img src="images/speed.png" class="img-fluid" alt="Responsive image"><br>'.
        $row_speedcar . ' km/h'.
        '</td>'.
        '</tr>'.
        '</table>';

    }
    $conn->close();
}
?>

    <!-- Main jQuery -->
    <script src='plugins/jquery/dist/jquery.min.js'></script>

    <!-- Bootstrap -->
    <script src='plugins/bootstrap/dist/js/popper.min.js'></script>
    <script src='plugins/bootstrap/dist/js/bootstrap.min.js'></script>

    <!-- Owl Carousel -->
    <script src='plugins/slick-carousel/slick/slick.min.js'></script>
    <script src='https://cdn.plot.ly/plotly-latest.min.js'></script>

    <!-- Smooth Scroll js -->
    <script src='plugins/smooth-scroll/dist/js/smooth-scroll.min.js'></script>

    <!-- Custom js -->
    <script src='js/script.js'></script>
    <script src='assets/jquery.min.js'></script>
    <script src='assets/script.js'></script>

</body>

</html>