
<?php
ini_set('display_errors', 1);
error_reporting(~0);
$serverName = "localhost";
$userName = "u348334018_gps"; 
$userPassword = "b]6dYFs&&=YV"; 
$dbName = "u348334018_gps"; 
$conn = mysqli_connect($serverName, $userName, $userPassword, $dbName);
$conn -> set_charset("utf8");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
  }
  /*echo "Connected successfully";*/
?>
