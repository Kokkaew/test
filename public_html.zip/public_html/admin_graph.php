<?php
    $servername = "localhost";
    $username = "u348334018_gps";
    $password = "b]6dYFs&&=YV";
    $dbname = "u348334018_gps";
    
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

	session_start();
	if($_SESSION['UserID'] == "")
	{
		echo "Please Login!";
		exit();
	}

	if($_SESSION['Status'] != "ADMIN")
	{
		echo "This page for Admin only!";
		exit();
	}	

	$strSQL = "SELECT * FROM member WHERE UserID = '".$_SESSION['UserID']."' ";
	$objQuery = mysqli_query($conn, $strSQL);
	$objResult = mysqli_fetch_array($objQuery);
?>
<html>
<head>
<title>GPS-Tracking: Graph</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png" />
  <link rel="stylesheet" href="plugins/themefisher-font.v-2/style.css">
  <link rel="stylesheet" href="plugins/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="plugins/slick-carousel/slick/slick.css">
  <link rel="stylesheet" href="plugins/slick-carousel/slick/slick-theme.css">
  <link rel="stylesheet" href="css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <style>
    #map {
      width: 100%;
      height: 550px;
    }
    .datatable{
        margin-right: 25px;
        margin-left: 25px;
    }
    .borderless {
        border: none;
    }
  </style>
</head>
<body>
<section class="header  navigation">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <nav class="navbar navbar-expand-lg">
                    <!--<a class="navbar-brand" href="index.html"><img src="images/logo-gps.png" class="img-responsive" alt="logo"></a>-->
                    <!--<a><img src="images/logo-gps.png" alt="logo"></a>-->
                    <a class="navbar-brand" href="index.html"><img src="images/kmutt.png" class="img-responsive" alt="logo"></a>
                    <a class="navbar-brand" href="index.html"><img src="images/nrct.png" class="img-responsive" alt="logo"></a>
                    <a class="navbar-brand" href="index.html"><img src="images/department_of_health.png" class="img-responsive" alt="logo"></a>
                    <span style="color:#FF5733"><b>บริษัท โชติฐกรณ์พิบูลย์ จำกัด</b></span>
                    <!--<a class="navbar-brand" href="index.html"><img src="images/kmutt02.png" class="img-responsive" alt="logo"></a>-->
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="tf-ion-android-menu"></span>
                    </button>  
                </nav>
            </div>
        </div>
    </div>
</section>


<section class="counter section-sm">
  <div class="container">
      <div class="text-left">
          <table class="table">
            <tbody>
              <tr>
                <td class="text-center" rowspan="2"><img src="https://gpstracking.landuselandcover.com/images/<?php echo $objResult["Picture"];?>" width="auto" height="100px">
                <p class="text-center"><a href="edit_profile.php">แก้ไขโปรไฟล์</a> | <a href="logout.php">ออกจากระบบ</a></p>               
              </td>
                <td> &nbsp;ชื่อผู้ใช้งาน: </td>
                <td class="text-left"><?php echo $objResult["Username"];?></td>
              </tr>
              <tr>
                <td> &nbsp;ชื่อ-นามสกุล: </td>
                <td class="text-left"><?php echo $objResult["Name"];?></td>
              </tr>
              <tr>
                <td></td>
                <td></td>
                <td class="text-right">
                    <button type="button" class="btn btn-info">View Report</button> | 
                    <button type="button" class="btn btn-info">Export data</button> | 
                    <button type="button" class="btn btn-info">Plot Maps</button> | 
                    <button type="button" class="btn btn-info"><a href="admin_graph.php" style="color:#ffffff">Plot Graph</a></button>
                </td>
              </tr>
            </tbody>
          </table>
          <hr>
 
<?php
  $servername = "localhost";
  $username = "u348334018_gps";
  $password = "b]6dYFs&&=YV";
  $dbname = "u348334018_gps";

  $conn = new mysqli($servername, $username, $password, $dbname);

  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }
  $sql = "SELECT * FROM provinces";
  $query = mysqli_query($conn, $sql);

?>

              
	  </div>
  </div>
</section>

<div class="container">
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <div id="chart_div" style="width: auto; height: 500px"></div>
    <script>
        google.charts.load('current', {packages: ['corechart', 'line']});
google.charts.setOnLoadCallback(drawCrosshairs);

function drawCrosshairs() {
      var data = new google.visualization.DataTable();
      data.addColumn('number', 'X');
      data.addColumn('number', 'past');
      data.addColumn('number', 'current');

      data.addRows([
        [0, 0, 0],    [1, 10, 5],   [2, 23, 15],  [3, 17, 9],   [4, 18, 10],  [5, 9, 5],
        [6, 11, 3],   [7, 27, 19],  [8, 33, 25],  [9, 40, 32],  [10, 32, 24], [11, 35, 27],
        [12, 30, 22], [13, 40, 32], [14, 42, 34], [15, 47, 39], [16, 44, 36], [17, 48, 40],
        [18, 52, 44], [19, 54, 46], [20, 42, 34], [21, 55, 47], [22, 56, 48], [23, 57, 49],
        [24, 60, 52], [25, 50, 42], [26, 52, 44], [27, 51, 43], [28, 49, 41], [29, 53, 45],
        [30, 55, 47], [31, 60, 52], [32, 61, 53], [33, 59, 51], [34, 62, 54], [35, 65, 57],
        [36, 62, 54], [37, 58, 50], [38, 55, 47], [39, 61, 53], [40, 84, 56], [41, 65, 57],
        [42, 63, 55], [43, 66, 58], [44, 67, 59], [45, 69, 61], [46, 69, 61], [47, 70, 62],
        [48, 72, 64], [49, 68, 60], [50, 66, 58], [51, 65, 57], [52, 67, 59], [53, 70, 62],
        [54, 71, 63], [55, 72, 64], [56, 73, 65], [57, 75, 67], [58, 70, 62], [59, 68, 60],
        [60, 64, 56], [61, 60, 52], [62, 65, 57], [63, 67, 59], [64, 68, 60], [65, 69, 61],
        [66, 70, 62], [67, 72, 64], [68, 75, 67], [69, 80, 72]
      ]);

      var options = {
        hAxis: {
          title: 'Time (h)'
        },
        vAxis: {
          title: 'Speed (km/h)'
        },
        colors: ['#a52714', '#097138'],
        crosshair: {
          color: '#000',
          trigger: 'selection'
        }
      };

      var chart = new google.visualization.LineChart(document.getElementById('chart_div'));

      chart.draw(data, options);
      chart.setSelection([{row: 40, column: 1}]);

    }
    </script>
</div>


<script src="plugins/jquery/dist/jquery.min.js"></script>
<script src="plugins/bootstrap/dist/js/popper.min.js"></script>
<script src="plugins/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="plugins/slick-carousel/slick/slick.min.js"></script>
<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
<script src="plugins/smooth-scroll/dist/js/smooth-scroll.min.js"></script>
<script src="js/script.js"></script>
<script src="assets/jquery.min.js"></script>
<script src="assets/script.js"></script>
</body>
</html>