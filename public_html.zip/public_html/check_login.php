<?php
session_start();
$serverName = 'localhost';
$userName = 'u348334018_gps';
$userPassword = 'b]6dYFs&&=YV';
$dbName = 'u348334018_gps';

$objCon = mysqli_connect( $serverName, $userName, $userPassword, $dbName );

$strSQL = "SELECT * FROM member WHERE Username = '".mysqli_real_escape_string( $objCon, $_POST[ 'txtUsername' ] )."' 
	and Password = '".mysqli_real_escape_string( $objCon, $_POST[ 'txtPassword' ] )."'";
$objQuery = mysqli_query( $objCon, $strSQL );
$objResult = mysqli_fetch_array( $objQuery, MYSQLI_ASSOC );
if ( !$objResult )
 {
    echo 'Username and Password Incorrect!';
} else {
    $_SESSION[ 'UserID' ] = $objResult[ 'UserID' ];
    $_SESSION[ 'Username' ] = $objResult[ 'Username' ];
    $_SESSION[ 'Status' ] = $objResult[ 'Status' ];

    session_write_close();

    if ( $objResult[ 'Status' ] == 'ADMIN' )
 {
        header( 'location:admin_page.php' );
    } else {
        if ( $objResult[ 'Username' ] == 'user01' ) {
            header( 'location:user_page.php' );
        } else {
            header( 'location:user_page2.php' );
        }

    }
}
mysqli_close( $objCon );
?>