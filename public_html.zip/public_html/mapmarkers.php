<?php
include('connect.php');

$dom = new DOMDocument("1.0");
$node = $dom->createElement("sensordata");
$parnode = $dom->appendChild($node);


$query = "SELECT * FROM sensordata";
$result = mysqli_query($conn, $query);

header("Content-type: text/xml");

while ($row = @mysql_fetch_assoc($result)){
  $node = $dom->createElement("marker");
  $newnode = $parnode->appendChild($node);
  $newnode->setAttribute("sensor",$row['sensor']);
  $newnode->setAttribute("lat_str",$row['lat_str']);
  $newnode->setAttribute("lng_str",$row['lng_str']);
  $newnode->setAttribute("statuscar",$row['statuscar']);
  $newnode->setAttribute("reading_time", $row['reading_time']);
  $newnode->setAttribute("speedcar",$row['speedcar']);
}

echo $dom->saveXML();

?>
