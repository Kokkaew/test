<html>
<head>
<title></title>
</head>
<body>
<?php 
    include('connect.php');
?>
      
<?php

    $sql_speed = "SELECT id, sensor, lat_str, lng_str, speedcar, statuscar, reading_time 
                  IF(statuscar>5,"รถวิ่ง","รถหยุดวิ่ง")"; 
    
?>
</body>
</html>