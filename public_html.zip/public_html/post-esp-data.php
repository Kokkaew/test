<?php
$servername = 'localhost';
$username = 'u348334018_gps';
$password = 'b]6dYFs&&=YV';
$dbname = 'u348334018_gps';

$api_key = $_GET[ 'api_key' ];
$sensor = $_GET[ 'sensor' ];
$lat_str = $_GET[ 'lat_str' ];
$lng_str = $_GET[ 'lng_str' ];
$speedcar = $_GET[ 'speedcar' ];
$statuscar = $_GET[ 'statuscar' ];

$val = $_GET[ 'val' ];
echo 'From Server-> Received: '.$val;

echo '<br>';
echo 'api_key: ' . $_GET[ 'api_key' ] . 'sensor: ' . $_GET[ 'sensor' ] . 'lat_str: ' . $_GET[ 'lat_str' ] . 'lng_str: ' . $_GET[ 'lng_str' ] . 'speedcar: ' . $_GET[ 'speedcar' ] . 'statuscar: ' . $_GET[ 'statuscar' ];
echo '<br>';

$api_key_value = 'tPmAT5Ab3j7F9';

$api_key = $sensor = $lat_str = $lng_str = $speedcar = $statuscar = '';

if ( $_SERVER[ 'REQUEST_METHOD' ] == 'POST' ) {
    $api_key = test_input( $_POST[ 'api_key' ] );
    if ( $api_key == $api_key_value ) {
        $sensor = test_input( $_POST[ 'sensor' ] );
        /*sensorName*/
        $lat_str = test_input( $_POST[ 'lat_str' ] );
        /*lat_str*/
        $lng_str = test_input( $_POST[ 'lng_str' ] );
        /*lng_str*/
        $speedcar = test_input( $_POST[ 'speedcar' ] );
        /*speedcar*/
        $statuscar = test_input( $_POST[ 'statuscar' ] );
        /*statuscar*/

        // Create connection
        $conn = new mysqli( $servername, $username, $password, $dbname );
        // Check connection
        if ( $conn->connect_error ) {
            die( 'Connection failed: ' . $conn->connect_error );
        }

        $sql = "INSERT INTO sensordata (sensor, lat_str, lng_str, speedcar, statuscar)
        VALUES ('" . $sensor . "', '" . $lat_str . "', '" . $lng_str . "', '" . $speedcar . "', '" . $statuscar . "')";

        /*$sql_delete = "DELETE FROM `sensordata` WHERE `lat_str` = ''";
        if ( $conn->query( $sql_delete ) === TRUE ) {
            echo 'New record created successfully';
        }

        $sql_update = "UPDATE `sensordata` SET `statuscar`='รถวิ่ง'";
        if ( $conn->query( $sql_update ) === TRUE ) {
            echo 'New record created successfully';
        }
        */

        //$sql_speed = "SELECT id, sensor, lat_str, lng_str, speedcar, statuscar, reading_time 
        //          IF(statuscar>5,"รถวิ่ง','รถหยุดวิ่ง')';

        //$sql = "DELETE FROM `sensordata` WHERE `lat_str` = ''";
        //$sql = "UPDATE `sensordata` SET `statuscar`='รถวิ่ง'";

        if ( $conn->query( $sql ) === TRUE ) {
            echo 'New record created successfully';
        } else {
            echo 'Error: ' . $sql . '<br>' . $conn->error;
        }

        $conn->close();
    } else {
        echo 'Wrong API Key provided.';
    }

} else {
    echo 'No data posted with HTTP POST.';
}

function test_input( $data ) {
    $data = trim( $data );
    $data = stripslashes( $data );
    $data = htmlspecialchars( $data );
    return $data;
}