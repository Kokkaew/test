<?php

$servername = "localhost";
$username = "u348334018_gps";
$password = "b]6dYFs&&=YV";
$dbname = "u348334018_gps";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}


$sql = "SELECT * FROM sensordata ORDER BY ID DESC";
$query = mysqli_query($conn, $sql);
while( $f = mysqli_fetch_assoc( $query ) ) {

}



$statement = $connect->prepare($query);

$statement->execute();

$result = $statement->fetchAll();

$total_row = $statement->rowCount();

$output = '';

if($total_row > 0)
{
 foreach($result as $row)
 {
  $output .= '
  <tr>
   <td>'.$row["ID"].'</td>
   <td>'.$row["sensor"].'</td>
   <td>'.$row["lat_str"].'</td>
   <td>'.$row["lng_str"].'</td>
   <td>'.$row["statuscar"].'</td>
  </tr>
  ';
 }
}
else
{
 $output .= '
 <tr>
  <td colspan="5" align="center">No Data Found</td>
 </tr>
 ';
}

echo $output;


?>
