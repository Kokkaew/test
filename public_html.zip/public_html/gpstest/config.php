<?php 
define('DB_HOST', 'localhost'); 
define('DB_USERNAME', 'u348334018_gpstracking2'); 
define('DB_PASSWORD', 'Xn&6padd'); 
define('DB_NAME', 'u348334018_gpstracking2');

date_default_timezone_set('Asia/Bangkok');

// Connect with the database 
$db = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME); 
 
// Display error if failed to connect 
if ($db->connect_errno) { 
    echo "Connection to database is failed: ".$db->connect_error;
    exit();
}