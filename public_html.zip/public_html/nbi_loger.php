<!DOCTYPE html>
<html lang="en">

<head>
    <!--<meta http-equiv='refresh' content='15'>-->
    <title></title>
</head>

<body>

    <?php
require_once 'connect.php';

// Check connection
if ( $conn->connect_error ) {
    die( 'Connection failed: ' . $conn->connect_error );
}

$sql_rm = "DELETE FROM `sensordata_nbi` WHERE `lng_str` = '0.000000'";
if ( $conn->query( $sql_rm ) === TRUE ) {
    echo '';
} else {
    echo '';
}

$sql_rm2 = "DELETE FROM `sensordata_nbi` WHERE `lat_str` = ''";
if ( $conn->query( $sql_rm2 ) === TRUE ) {
    echo '';
} else {
    echo '';
}

$sql_icon = "UPDATE `sensordata_nbi` SET `icon`='track-red.png'";
if ( $conn->query( $sql_icon ) === TRUE ) {
    echo '';
} else {
    echo '';
}

$sql_stop = "UPDATE `sensordata_nbi` SET `statuscar`='Stop' WHERE speedcar < 1";
if ( $conn->query( $sql_stop ) === TRUE ) {
    echo '';
} else {
    echo '';
}

$sql_run = "UPDATE `sensordata_nbi` SET `statuscar`='Runing' WHERE speedcar >= 1";
if ( $conn->query( $sql_run ) === TRUE ) {
    echo '';
} else {
    echo '';
}

$sql_agency = "UPDATE `sensordata_nbi` SET `agency`='เทศบาลเมืองสุพรรณบุรี'";
if ( $conn->query( $sql_agency ) === TRUE ) {
    echo '';
} else {
    echo '';
}

/*$sql_id = "ALTER TABLE `sensordata_nbi` AUTO_INCREMENT = 1";
if ( $conn->query( $sql_id ) === TRUE ) {
    echo '';
} else {
    echo '';
}*/



$sql = "SELECT id, sensor, lat_str, lng_str, speedcar, statuscar, reading_time 
		FROM sensordata_nbi 
		ORDER BY id DESC LIMIT 100";

/*
$bbdate = date( 'd-m-Y', strtotime( '-1 day' ) );
$sqlnews = "SELECT * FROM news WHERE date >= '$bbdate'-1 and date = '$bbdate'  ORDER BY  RAND() LIMIT 10";
*/


echo '<table cellspacing="5" cellpadding="5" class="table table-striped table-hover">
	   <tr>
		<th>ลำดับ</th>
		<th>วัน/เวลา</th>
		<th>ทะเบียนรถ</thh>
		<th>ละติจูด</th>
		<th>ลองจิจูด</th>
		<th>ความเร็ว</th>
		<th>สถานะ</th>
		<th>รายละเอียด</th>
	  </tr>';

if ( $result = $conn->query( $sql ) ) {
    while ( $row = $result->fetch_assoc() ) {
        $row_id = $row[ 'id' ];
        $row_reading_time = $row[ 'reading_time' ];
        $row_sensor = $row[ 'sensor' ];
        $row_lat_str = $row[ 'lat_str' ];
        $row_lng_str = $row[ 'lng_str' ];
        $row_speedcar = $row[ 'speedcar' ];

        $row_statuscar = $row[ 'statuscar' ];

        $row_reading_time = date( 'Y-m-d H:i:s', strtotime( "$row_reading_time + 7 hours" ) );

        echo '<tr> 
				<td>' . $row_id . '</td>
				<td>' . $row_reading_time . '</td> 
				<td>' . $row_sensor . '</td>
				<td>' . $row_lat_str . '</td> 
				<td>' . $row_lng_str . '</td> 
				<td>' . $row_speedcar . '</td>
				<td>' . $row_statuscar . '</td>
				<td><a href="detail.php?sensor='. $row_sensor .'&lat_str=' . $row_lat_str . '&lng_str=' . $row_lng_str . '&status_str='. $row_statuscar . '&speed_str=' . $row_speedcar . '&time_str=' . $row_reading_time . '" target="_blank"> รายละเอียด </a></td>
			  </tr>';
    }
    $result->free();
}

$conn->close();
?>

</body>

</html>