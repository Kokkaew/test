<?php 
    $a = fopen("logger.txt");
    $b = "####".date("d M Y H:i:s")."####\r\n";

    fputs($a,$d);
    fputs($a,"ID=".$id);
    fputs($a,"");
    fputs($a,"VALUE=".$value);

    fputs($a,"\r\n");
    fclose($a);

    echo("Server received ID = $id & VALUE = $value");
?>