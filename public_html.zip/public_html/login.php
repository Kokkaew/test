<!DOCTYPE html>
<html lang="en">

<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="description" content="Bingo One page parallax responsive HTML Template ">

<meta name="author" content="Themefisher.com">

<title>GPS-Tracking</title>

<meta name="viewport" content="width=device-width, initial-scale=1">


<link rel="shortcut icon" type="image/x-icon" href="img/favicon.png" />

<link rel="stylesheet" href="plugins/themefisher-font.v-2/style.css">

<link rel="stylesheet" href="plugins/bootstrap/dist/css/bootstrap.min.css">

<link rel="stylesheet" href="plugins/slick-carousel/slick/slick.css">
<link rel="stylesheet" href="plugins/slick-carousel/slick/slick-theme.css">

<link rel="stylesheet" href="css/style.css">



</head>

<body id="body">
    <div id="preloader">
        <div class="preloader">
            <div class="sk-circle1 sk-child"></div>
            <div class="sk-circle2 sk-child"></div>
            <div class="sk-circle3 sk-child"></div>
            <div class="sk-circle4 sk-child"></div>
            <div class="sk-circle5 sk-child"></div>
            <div class="sk-circle6 sk-child"></div>
            <div class="sk-circle7 sk-child"></div>
            <div class="sk-circle8 sk-child"></div>
            <div class="sk-circle9 sk-child"></div>
            <div class="sk-circle10 sk-child"></div>
            <div class="sk-circle11 sk-child"></div>
            <div class="sk-circle12 sk-child"></div>
        </div>
    </div>

    <section class="header  navigation">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-expand-lg">
                        <a class="navbar-brand" href="index.html"><img src="images/kmutt-th.png" class="img-responsive"
                                alt="logo"></a>
                        <a class="navbar-brand" href="index.html"><img src="images/nrct-logo.png" class="img-responsive"
                                alt="logo"></a>
                        <a class="navbar-brand" href="index.html"><img src="images/department_of_health.png"
                                class="img-responsive" alt="logo"></a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse"
                            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="tf-ion-android-menu"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item active">
                                    <a class="nav-link" href="index.php">หน้าแรก <span
                                            class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="about.php">ข้อมูลโครงการ</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="contact.php">ติดต่อเรา</a>
                                </li>
                            </ul>
                        </div>
                        <div class="topnav">
                            <div class="login-container">
                                <a href="login.php"><img src="images/login/sign-in.png" alt="logo"></a>
                            </div>
                        </div>
                    </nav>

                </div>
            </div>
        </div>
    </section>

    <section class="signin-page account">
        <div class="container">
            <div class="row">
                <div class="col-md-6 mx-auto">
                    <div class="block">
                        <h2 class="text-center">Sign In GPS-Tracking</h2>
                        <form name="form1" method="post" action="check_login.php" class="text-left clearfix mt-50"
                            action="index.html">
                            <div class="form-group">
                                <label for="exampleFormControlInput1" class="form-label">ชื่อผู้ใช้:</label>
                                <input name="txtUsername" type="text" id="txtUsername" class="form-control"
                                    placeholder="Username">
                            </div>
                            <div class="form-group">
                                <label for="exampleFormControlInput1" class="form-label">รหัสผ่าน:</label>
                                <input name="txtPassword" type="password" id="txtPassword" class="form-control"
                                    placeholder="Password">
                            </div>
                            <button type="submit" name="Submit" class="btn btn-main">เข้าสู่ระบบ</button>
                            <button type="reset" name="Submit" class="btn btn-main">เคลียร์</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="plugins/jquery/dist/jquery.min.js"></script>

    <script src="plugins/bootstrap/dist/js/popper.min.js"></script>
    <script src="plugins/bootstrap/dist/js/bootstrap.min.js"></script>

    <script src="plugins/slick-carousel/slick/slick.min.js"></script>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>

    <script src="plugins/smooth-scroll/dist/js/smooth-scroll.min.js"></script>

    <script src="js/script.js"></script>

</body>

</html>