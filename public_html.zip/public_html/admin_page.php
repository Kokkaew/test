<?php
require_once 'connect.php';

session_start();
if($_SESSION['UserID'] == "")
{
  echo "Please Login!";
  exit();
}

if($_SESSION['Status'] != "ADMIN")
{
  echo "This page for Admin only!";
  exit();
}	

$strSQL = "SELECT * FROM member WHERE UserID = '".$_SESSION['UserID']."' ";
$objQuery = mysqli_query($conn, $strSQL);
$objResult = mysqli_fetch_array($objQuery);


$sql_sensor = "SELECT DISTINCT sensor FROM sensordata UNION SELECT DISTINCT sensor FROM sensordata_nbi;";
$query_sensor = mysqli_query($conn, $sql_sensor);

$sql_statuscar = "SELECT DISTINCT statuscar FROM sensordata UNION SELECT DISTINCT statuscar FROM sensordata_nbi;";
$query_statuscar = mysqli_query($conn, $sql_statuscar);

$sql_sensor_count1 = "SELECT COUNT(DISTINCT sensor) FROM sensordata;";
$query_sensor_count1 = mysqli_query($conn, $sql_sensor_count1);

$sql_sensor_count2 = "SELECT COUNT(DISTINCT sensor) FROM sensordata_nbi;";
$query_sensor_count2 = mysqli_query($conn, $sql_sensor_count2);

$sql_sensorID_count1 = "SELECT COUNT(ID) FROM sensordata";
$query_sensorID_count1 = mysqli_query($conn, $sql_sensorID_count1);

$sql_sensorID_count2 = "SELECT COUNT(ID) FROM sensordata";
$query_sensorID_count2 = mysqli_query($conn, $sql_sensorID_count2);

?>


<html>
<head>
<title>GPS-Tracking</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png" />
  <link rel="stylesheet" href="plugins/themefisher-font.v-2/style.css">
  <link rel="stylesheet" href="plugins/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="plugins/slick-carousel/slick/slick.css">
  <link rel="stylesheet" href="plugins/slick-carousel/slick/slick-theme.css">
  <link rel="stylesheet" href="css/style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

  <!-- เรียกใช้ javascript สำหรับ export ไฟล์ excel  -->
  <script src="https://unpkg.com/xlsx/dist/xlsx.full.min.js"  ></script>
  <script src="https://unpkg.com/file-saver@1.3.3/FileSaver.js"  ></script>

<!-- Font -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@100;200&display=swap" rel="stylesheet">


  <style>
    body{
      font-family: 'Sarabun', sans-serif;
    }
    #map {
      width: 100%;
      height: 550px;
    }
    /*.datatable{
        margin-right: 25px;
        margin-left: 25px;
    }*/
    .borderless {
        border: none;
    }
  </style>
</head>
<body>


<section class="header navigation">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-expand-lg">
                        <a class="navbar-brand" href="index.html"><img src="images/kmutt-th.png" class="img-responsive"
                                alt="logo"></a>
                        <a class="navbar-brand" href="index.html"><img src="images/nrct-logo.png" class="img-responsive"
                                alt="logo"></a>
                        <a class="navbar-brand" href="index.html"><img src="images/department_of_health.png"
                                class="img-responsive" alt="logo"></a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse"
                            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="tf-ion-android-menu"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item active">
                                    <!--<a class="nav-link" href="index.php">หน้าแรก <span
                                            class="sr-only">(current)</span></a>-->
                                </li>
                                <li class="nav-item">
                                    <!--<a class="nav-link" href="about.php">ข้อมูลโครงการ</a>-->
                                </li>
                                <li class="nav-item">
                                    <!--<a class="nav-link" href="contact.php">ติดต่อเรา</a>-->
                                </li>
                            </ul>
                        </div>
                        <div class="topnav">
                            <div class="login-container">
                                <a href="logout.php"><b>ชื่อเจ้าหน้าที่:</b> <?php echo $objResult["Username"];?>
                                    <img src="images/login/log-out.png" class="img-responsive" alt=""></a>
                            </div>
                        </div>
                    </nav>

                </div>
            </div>
        </div>
    </section>

    <br>


<section class="counter section-sm">
  <div class="container">
      <div class="text-left">
      <div class="row">
                <div class="col-8">
                    <div class="card">
                        <div class="p-3 bg-light text-dark">
                            <div class="card-body">
                                <p><b>ชื่อ-นามสกุล:</b> <?php echo $objResult["Name"];?></p>
                                <p><b>หน่วยงาน:</b> สำนักอนามัยสิ่งแวดล้อม กรมอนามัย</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-4">
                    <div class="card">
                        <div class="p-3 bg-light text-dark">
                            <div class="card-body">
                                <p><b>จำนวนรถ:</b>
                                    <?php
                                        $sensorResult1 = $query_sensor_count1->fetch_array()[0] ?? '';
										$sensorResult2 = $query_sensor_count2->fetch_array()[0] ?? '';
                                        echo number_format($sensorResult1+$sensorResult2);
                                    ?> คัน</p>
                                <p><b>จำนวนข้อมูล:</b>
                                    <?php
                                        $recordResult1 = $query_sensorID_count1->fetch_array()[0] ?? '';
										$recordResult2 = $query_sensorID_count2->fetch_array()[0] ?? '';
                                        echo number_format($recordResult1+$recordResult2);
                                ?> เรคคอร์ด</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

          <hr>
 
          <!-- แบบฟอร์มค้นหาข้อมูล -->
          <form class="form-inline" method="get" action="admin_page2.php">
            <div class="input-group mr-2">
              <div class="input-group-prepend">
                <div class="input-group-text">ทะเบียนรถ</div>
              </div>
              <select name="sensor" class="form-control">
                <option value="">ทั้งหมด</option>
                <?php while ($result = mysqli_fetch_assoc($query_sensor)): ?>
                <option value="<?= $result["sensor"] ?>"><?= $result["sensor"] ?></option>
                <?php endwhile; ?>
              </select>
            </div>

            <div class="input-group mr-2">
              <div class="input-group-prepend">
                <div class="input-group-text">สถานะ</div>
              </div>
              <select name="statuscar" class="form-control">
                <option value="">ทั้งหมด</option>
                <?php while ($result2 = mysqli_fetch_assoc($query_statuscar)): ?>
                <option value="<?= $result2["statuscar"] ?>"><?= $result2["statuscar"] ?></option>
                <?php endwhile; ?>
              </select>
            </div>

            <div class="input-group mr-2">
                <button type="submit" class="btn btn-primary">ค้นหา</button>
            </div>
            <div class="input-group mr-2">
                <button type="reset"class="btn btn-warning">เคลียร์</button>
            </div>
            <div class="input-group mr-2">
              <a href="admin_report.php"><button type="button" class="btn btn-success">รายงาน</button></a>
            </div>
            <div class="input-group mr-2">
              <a href="admin_export.php"><button type="button" class="btn btn-success">ดาวน์โหลด</button></a>
            </div>   
          </form>
          <!-- End -->
			</div>

      <div class="datatable">
        <?php
          $sql = "SELECT * FROM sensordata UNION SELECT * FROM sensordata_nbi ORDER BY ID DESC LIMIT 50;";
          
          echo '<table cellspacing="5" cellpadding="5" class="table table-striped table-hover">
              <tr>
                <th>ลำดับ</th>
                <th>วัน/เวลา</th>
                <th>ทะเบียนรถ</thh>
                <th>ละติจูด</th>
                <th>ลองจิจูด</th>
                <th>ความเร็ว</th>
                <th>สถานะ</th>
                <th>รายละเอียด</th>
              </tr>';
            
          if ($result = $conn->query($sql)) {
            while ($row = $result->fetch_assoc()) {
              $row_id = $row["ID"];
              $row_reading_time = $row["reading_time"];
              $row_sensor = $row["sensor"];
              $row_lat_str = $row["lat_str"];
              $row_lng_str = $row["lng_str"];
              $row_speedcar = $row["speedcar"]; 
              $row_statuscar = $row["statuscar"];
              $row_reading_time = date("Y-m-d H:i:s", strtotime("$row_reading_time + 7 hours")); 
            
              echo '<tr> 
                      <td>' . number_format($row_id) . '</td>
                      <td>' . $row_reading_time . '</td>
                      <td>' . $row_sensor . '</td>
                      <td>' . $row_lat_str . '</td>
                      <td>' . $row_lng_str . '</td>
                      <td>' . $row_speedcar . '</td>
                      <td>' . $row_statuscar . '</td>
                      <td><a href="detail.php?sensor='. $row_sensor .'&lat_str=' . $row_lat_str . '&lng_str=' . $row_lng_str . '&status_str='. $row_statuscar . '&speed_str=' . $row_speedcar . '&time_str=' . $row_reading_time . '" target="_blank"> รายละเอียด </a></td>
                  </tr>';
            }
            $result->free();
          }
          $conn->close();
        ?>
    </div>
  </div>
</section>

<script src="plugins/jquery/dist/jquery.min.js"></script>
<script src="plugins/bootstrap/dist/js/popper.min.js"></script>
<script src="plugins/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="plugins/slick-carousel/slick/slick.min.js"></script>
<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
<script src="plugins/smooth-scroll/dist/js/smooth-scroll.min.js"></script>
<script src="js/script.js"></script>
<script src="assets/jquery.min.js"></script>
<script src="assets/script.js"></script>
</body>
</html>