$(function(){
    var provinceObject = $('#sensor');
    var statuscarObject = $('#statuscar');

    // on change province
    provinceObject.on('change', function(){
        var provinceId = $(this).val();

        statuscarObject.html('<option value="">ทั้งหมด</option>');

        $.get('get_statuscar.php?sensor=' + provinceId, function(data){
            var result = JSON.parse(data);
            $.each(result, function(index, item){
                statuscarObject.append(
                    $('<option></option>').val(item.sensor).html(item.sensor)
                );
            });
        });
    });
});