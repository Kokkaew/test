<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <!--<meta http-equiv="refresh" content="5" >-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>GPS Tracking</title>
    <link href="assets/bootstrap.min.css" rel="stylesheet">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


    <title>GPS-Tracking</title>

    <!-- Mobile Specific Meta
  ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png" />

    <!-- CSS
  ================================================== -->
    <!-- Themefisher Icon font -->
    <link rel="stylesheet" href="plugins/themefisher-font.v-2/style.css">
    <!-- bootstrap.min css -->
    <link rel="stylesheet" href="plugins/bootstrap/dist/css/bootstrap.min.css">
    <!-- Slick Carousel -->
    <link rel="stylesheet" href="plugins/slick-carousel/slick/slick.css">
    <link rel="stylesheet" href="plugins/slick-carousel/slick/slick-theme.css">
    <!-- Main Stylesheet -->
    <link rel="stylesheet" href="css/style.css">

    <!-- Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@100;200&display=swap" rel="stylesheet">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

    <style>
    body {
        font-family: 'Sarabun', sans-serif;
    }

    #map {
        width: 100%;
        height: 550px;
    }

    .datatable {
        margin-right: 25px;
        margin-left: 25px;
    }

    .scrollit {
        overflow: scroll;
        height: 550px;
    }
    </style>

</head>

<body onload="init();">
    <div id="preloader">
        <div class="preloader">
            <div class="sk-circle1 sk-child"></div>
            <div class="sk-circle2 sk-child"></div>
            <div class="sk-circle3 sk-child"></div>
            <div class="sk-circle4 sk-child"></div>
            <div class="sk-circle5 sk-child"></div>
            <div class="sk-circle6 sk-child"></div>
            <div class="sk-circle7 sk-child"></div>
            <div class="sk-circle8 sk-child"></div>
            <div class="sk-circle9 sk-child"></div>
            <div class="sk-circle10 sk-child"></div>
            <div class="sk-circle11 sk-child"></div>
            <div class="sk-circle12 sk-child"></div>
        </div>
    </div>

    <section class="header  navigation">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-expand-lg">
                        <a class="navbar-brand" href="index.html"><img src="images/kmutt-th.png" class="img-responsive"
                                alt="logo"></a>
                        <a class="navbar-brand" href="index.html"><img src="images/nrct-logo.png" class="img-responsive"
                                alt="logo"></a>
                        <a class="navbar-brand" href="index.html"><img src="images/department_of_health.png"
                                class="img-responsive" alt="logo"></a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse"
                            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="tf-ion-android-menu"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php">หน้าแรก <span
                                            class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item active">
                                    <a class="nav-link" href="about.php">ข้อมูลโครงการ</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="contact.php">ติดต่อเรา</a>
                                </li>
                            </ul>
                        </div>
                        <div class="topnav">
                            <div class="login-container">
                                <a href="login.php"><img src="images/login/sign-in.png" alt="logo"></a>
                            </div>
                        </div>
                    </nav>

                </div>
            </div>
        </div>
    </section>

    <br>

    <section class="services section-xs" id="services">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">ข้อมูลโครงการ</h5>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">โครงการ:
                                การพัฒนาระบบติดตามตรวจสอบการขนส่งและกำจัดมูลฝอยติดเชื้อแบบเรียลไทม์</h5>
                            <h5 class="card-title">Project: Development of a real time monitoring system for infectious
                                waste transport and disposal</h5>
                            <p class="card-text"><b>หน่วยงานหลัก</b></p>
                            <p class="card-text">คณะวิทยาศาสตร์ มหาวิทยาลัยเทคโนโลยีพระจอมเกล้าธนบุรี</p>
                            <p class="card-text">126 ถ. ประชาอุทิศ แขวงบางมด เขตทุ่งครุ กรุงเทพมหานคร 10140</p>
                            <p class="card-text">โทรศัพท์: 02-470-8000</p>
                            <hr>
                            <p class="card-text"><b>หน่วยสนับสุน</b></p>
                            <p class="card-text">สำนักอนามัยสิ่งแวดล้อม กรมอนามัย</p>
                            <p class="card-text">ที่อยู่ 88/22 หมู่ 4 ถนนติวานนท์ ตำบลตลาดขวัญ อำเภอเมือง</p>
                            <p class="card-text">จังหวัดนนทบุรี รหัสไปรษณีย์ 11000</p>
                            <p class="card-text">โทรศัพท์: 02 590 4128, 02 590 4655</p>
                        </div>
                    </div>
                </div>
            </div>

            </br>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">ที่มาและความสำคัญ</h5>
                        </div>
                        <div class="card-body">
                            <!--<h5 class="card-title">โครงการ: การพัฒนาระบบเก็บมูลฝอยติดเชื้ออัจฉริยะและระบบติดตามตรวจสอบการขนส่งและ</h5>-->
                            <p class="card-text">ในปีพ.ศ. 2557
                                รัฐบาลได้กำหนดให้การจัดการขยะมูลฝอยและของเสียอันตรายเป็นวาระแห่งชาติที่ทุกภาคส่วนต้องเร่งดำเนินการบริหารจัดการ
                                เพื่อลดมลพิษที่เกิดจากการตกค้าง สะสมของขยะมูลฝอย ซึ่งหน่วยงานที่เกี่ยวข้องทั้งภาครัฐ
                                ภาคเอกชน และประชาชน
                                ได้ดำเนินงานเพื่อแก้ไขปัญหาการจัดการขยะมูลฝอยของประเทศไทยอย่างต่อเนื่อง
                                โดยในส่วนขยะมูลฝอยติดเชื้อ กรมอนามัย กระทรวงสาธารณสุข มีหน้าที่หลักในการบริหารจัดการ
                                กำกับ ติดตาม ตรวจสอบมูลฝอยติดเชื้อทั้งระบบ
                                ตั้งแต่แหล่งกำเนิดมูลฝอยติดเชื้อไปจนถึงแหล่งกำจัดมูลฝอยติดเชื้อ
                                ประกอบกับสถานการณ์การระบาดของไวรัสโคโรน่าสายพันธุ์ใหม่ หรือ โควิด-19
                                ทำให้เกิดปัญหาโรคอุบัติใหม่ หรือโรคอุบัติซ้ำ (emerging or new infectious disease)
                                ที่ร้ายแรง และการแพร่ระบาดของโควิด-19 จากซีกโลกหนึ่งไปยังอีกซีกโลกหนึ่งอย่างรวดเร็ว
                                ส่งผลกระทบโดยตรงต่อสุขภาพและการใช้ชีวิตประจำวันของประชาชนที่สวมหน้ากากอนามัยเพื่อป้องกันการติดเชื้อ
                                อีกทั้งการรักษาผู้ป่วยติดเชื้อ การครองเตียงที่นานขึ้น
                                ส่งผลให้อัตราการเกิดมูลฝอยติดเชื้อในสถานพยาบาลเพิ่มขึ้น
                                ประกอบกับข้อมูลจากศูนย์วิจัยกสิกรไทยพบว่า ปี 2564 ปริมาณมูลฝอยติดเชื้อจะมีประมาณ 61.3
                                ล้านตัน ซึ่งเพิ่มขึ้นประมาณ 2 เท่าจากปี 2562 </p>
                            <p class="card-text">ดังนั้นการบริหารจัดการมูลฝอยติดเชื้อที่มีประสิทธิภาพจากทั้งแหล่งกำเนิด
                                ระหว่างการขนส่งมูลฝอยติดเชื้อที่ขนส่งโดยพาหนะ และแหล่งกำจัด
                                ถือว่าเป็นส่วนหนึ่งที่สามารถรองรับมาตรการการลดการแพร่กระจายของเชื้อโรคจากมูลฝอยติดเชื้อไปสู่มนุษย์ได้
                                กรมอนามัยได้เสนอแนวทางในการพัฒนาระบบบริหารจัดการมูลฝอยติดเชื้อ โดยการใช้เทคโนโลยี ข้อมูล
                                หรือเครื่องมือต่างๆ ที่จะช่วยเพิ่มประสิทธิภาพการบริหารจัดการมูลฝอยติดเชื้อตลอดห่วงโซ่
                                กล่าวคือ ทั้งจากแหล่งกำเนิด ระหว่างการขนส่งมูลฝอยติดเชื้อไปยังแหล่งกำจัด
                                โดยสามารถเก็บข้อมูลปริมาณมูลฝอยติดเชื้อจากแหล่งกำเนิดและแหล่งกำจัดแบบเรียลไทม์
                                เส้นทางการขนส่งมูลฝอยติดเชื้อจากแหล่งกำเนิดไปยังแหล่งกำจัด ซึ่งนำไปสู่การติดตาม
                                การวิเคราะห์ และวางแผนการบริหารจัดการมูลฝอยติดเชื้อให้เหมาะสม
                                และเพียงพอต่อการรองรับปริมาณมูลฝอยติดเชื้อที่เพิ่มขึ้น</p>
                            <p class="card-text">เพื่อเพิ่มประสิทธิภาพสำหรับระบบการบริหารจัดการมูลฝอยติดเชื้อดังกล่าว
                                เทคโนโลยีด้านประมวลผลภาพ (Image Processing) และเทคนิคการรียนรู้ของเครื่อง (Machine
                                Learning)
                                จะนำมาประยุกต์ใช้ในการเก็บปริมาณมูลฝอยติดเชื้อซึ่งเทคโนโลยีนี้สามารถนำไปประยุกต์ใช้กับเครื่องชั่งรุ่นต่างกันๆ
                                ได้
                                โดยเทคโนโลยีดังกล่าวสามารถทดแทนการใช้เครื่องชั่งรุ่นเฉพาะที่ต้องใช้คู่กับอุปกรณ์การส่งข้อมูล
                                ซึ่งข้อมูลจะถูกเก็บบน cloud โดยเครื่องชั่งและอุปกรณ์นี้มีราคาประมาณ 50,000 บาทต่อชุด
                                อีกทั้งโปรแกรมที่ใช้ในการอ่านข้อมูลสามารถอ่านข้อมูลได้เฉพาะเจาะจงรุ่นของเครื่องชั่งนั้นๆ
                                ไม่สามารถขยายผลไปยังเครื่องชั่งรุ่นอื่นๆ ได้ สำหรับการติดตามยานพาหนะขนส่งมูลฝอยติดเชื้อ
                                เทคโนโลยีสารสนเทศภูมิศาสตร์ (Geographic Information Systems, GIS)
                                นำมาใช้ในการติดตามจากแหล่งกำเนิดไปยังแหล่งกำจัดมูลฝอยติดเชื้อ
                                เพื่อลดการลักลอบทิ้งมูลฝอยติดเชื้อตามที่สาธารณะ
                                สำหรับการนำข้อมูลไปใช้ประโยชน์ในการบริหารจัดการมูลฝอยติดเชื้อ การวิเคราะห์ข้อมูล (Data
                                Analytics) และรายงานผลอัจฉริยะ (Dashboard) แบบทันท่วงที (Real-time monitoring)
                                นำมาประยุกต์ใช้ในโครงการนี้
                                โดยการแสดงผลจะแสดงปริมาณมูลฝอยติดเชื้อจากแหล่งกำเนิดและแหล่งกำจัดที่ง่ายต่อความเข้าใจ
                                ผู้เกี่ยวข้องสามารถนำรายงานดังกล่าวเป็นข้อมูลประกอบในการบริหารจัดการมูลฝอยติดเชื้อได้อย่างเหมาะสม
                                อีกทั้งการมีสมการคณิตศาสตร์ที่สามารถพยากรณ์ปริมาณมูลฝอยติดเชื้อที่จะเกิดขึ้นในอนาคต
                                ผู้เกี่ยวข้องสามารถนำไปวางแผน บริหารจัดการล่วงหน้าได้อย่างเหมาะสม
                                ซึ่งถือว่าเป็นประโยชน์ต่อหน่วยงานที่เกี่ยวข้องที่สามารถดำเนินการจัดการมูลฝอยติดเชื้อได้อย่างมีประสิทธิภาพมากขึ้น
                            </p>
                            <p class="card-text">โครงการวิจัยนี้จึงประกอบด้วย 3 กิจกรรมหลักได้แก่ กิจกรรมที่ 1
                                การพัฒนาระบบจัดเก็บข้อมูลและติดตามการขนส่งและกำจัดมูลฝอยติดเชื้อด้วยสมาร์ทแอพพลิเคชั่น
                                กิจกรรมที่ 2
                                ระบบวิเคราะห์และแสดงผลข้อมูลระบบควบคุมกำกับการเก็บขนมูลฝอยติดเชื้อแบบเรียลไทม์
                                และกิจกรรมที่ 3 จะนำข้อมูลที่ได้จากกิจกรรมที่ 1 มาสร้างสมการพยากรณ์โดยผ่านกระบวนการ Data
                                Pre-Processing และ Predictive modeling process
                                และเมื่อได้สมการที่สามารถใช้งานได้จริงแล้ว จะนำสมการดังกล่าวไปใช้งานโดยสามารถแสดงผลบน
                                dashboard ร่วมกับกิจกรรมที่ 2 โดยพื้นที่นำร่องในการดำเนินงานประกอบด้วย
                                แหล่งกำเนิดมูลฝอยติดเชื้อได้แก่ โรงพยาบาลแม่ข่าย สังกัดกระทรวงสาธารณสุข จำนวน 12 แห่ง
                                ที่ตั้งอยู่ในจังหวัดพิจิตร บริษัทขนส่งและแหล่งกำจัดมูลฝอยติดเชื้อได้แก่ บริษัทโชติฐกรณ์
                                จำกัด จังหวัดนครสรรค์</p>
                            <p class="card-text">โดยผลผลิตที่คาดว่าจะได้จากโครงการนี้ได้แก่ 1.
                                แอพพลิเคชั่นที่สามารถอ่านปริมาณมูลฝอยติดเชื้อจากแหล่งกำเนิดและแหล่งกำจัด 2.
                                แอพพลิเคชั่นสำหรับติดตามพาหนะขนส่ง ซึ่งสะดวกในการใช้งาน (user friendly) 3.
                                รายงานผลอัจฉริยะ (dashboard) ที่แสดงปริมาณมูลฝอยติดเชื้อจากแหล่งกำเนิดและแหล่งกำจัด 4.
                                สมการที่สามารถพยากรณ์ปริมาณมูลฝอยติดเชื้อในอนาคต และ 5.
                                ปริมาณข้อมูลมูลฝอยติดเชื้อที่มีจำนวนมากขึ้น (Big data)
                                ส่งผลให้ในอนาคตสามารถนำข้อมูลส่วนนี้ไปวิเคราะห์ (Big data analytics)
                                ให้เกิดประโยชน์ต่อการบริหารจัดการมูลฝอยติดเชื้อต่อไปได้</p>
                        </div>
                    </div>
                </div>
            </div>

            </br>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">กรอบแนวคิดของโครงการ</h5>
                        </div>
                        <div class="card-body">
                            <!--h5 class="card-title">โครงการ: การพัฒนาระบบเก็บมูลฝอยติดเชื้ออัจฉริยะและระบบติดตามตรวจสอบการขนส่งและ</h5>
                <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>-->
                            <img class="card-img-top" src="images/concept.png" alt="กรอบแนวคิดของโครงการ">
                        </div>
                    </div>
                </div>
            </div>

            </br>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">เป้าหมายสำคัญของโครงการ</h5>
                        </div>
                        <div class="card-body">
                            <!--<h5 class="card-title">โครงการ: การพัฒนาระบบเก็บมูลฝอยติดเชื้ออัจฉริยะและระบบติดตามตรวจสอบการขนส่งและ</h5>-->
                            <p class="card-text">1) พัฒนาระบบตรวจสอบน้ำหนักและระบบติดตามการขนส่งมูลฝอยติดเชื้อ</p>
                            <p class="card-text">2)
                                พัฒนาระบบวิเคราะห์และแสดงผลข้อมูลสำหรับการขนส่งและการกำจัดมูลฝอยติดเชื้อแบบเรียลไทม์
                                เพื่อนำไปประกอบการใช้เป็นแนวทางบริหารจัดการปริมาณมูลฝอยติดเชิ้อได้อย่างมีประสิทธิภาพและยั่งยืน
                            </p>
                            <p class="card-text">3) สร้างสมการพยากรณ์ปริมาณมูลฝอยติดเชื้อ </p>
                        </div>
                    </div>
                </div>
            </div>

            </br>
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title">คณะวิจัยและผู้มีส่วนร่วม</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-4">
                                    <div class="card" style="">
                                        <img class="card-img-top" src="images/kmutt.png" class="img-responsive" alt="">
                                        <div class="card-body">
                                            <h5 class="card-title">มหาวิทยาลัยเทคโนโลยีพระจอมเกล้าธนบุรี</h5>
                                            <p class="card-text">หน่วยงานหลัก</p>
                                            <a href="#" class="btn btn-primary">ติดต่อ</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="card" style="">
                                        <img class="card-img-top" src="images/nrct-logo.png" class="img-responsive"
                                            alt="">
                                        <div class="card-body">
                                            <h5 class="card-title">สำนักงานการวิจัยแห่งชาติ (วช.)</h5>
                                            <p class="card-text">สนับสนุน</p>
                                            <a href="#" class="btn btn-primary">ติดต่อ</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="card" style="">
                                        <img class="card-img-top" src="images/department_of_health.png"
                                            class="img-responsive" alt="">
                                        <div class="card-body">
                                            <h5 class="card-title">กรมอนามัย กระทรวงสาธารณสุข</h5>
                                            <p class="card-text">หน่วยงานสนับสนุน</p>
                                            <a href="#" class="btn btn-primary">ติดต่อ</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div>
    </section>
    <!--<footer id="footer" class="bg-one">
  <div class="footer-bottom">
    <h5>Copyright 2017. All rights reserved.</h5>
    <h6>Design and Developed by <a href="">Themefisher</a></h6>
  </div>
</footer>-->
    <script src="plugins/jquery/dist/jquery.min.js"></script>
    <script src="plugins/bootstrap/dist/js/popper.min.js"></script>
    <script src="plugins/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="plugins/slick-carousel/slick/slick.min.js"></script>
    <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
    <script src="plugins/smooth-scroll/dist/js/smooth-scroll.min.js"></script>
    <script src="js/script.js"></script>
    <script src="assets/jquery.min.js"></script>
    <script src="assets/script.js"></script>
</body>

</html>