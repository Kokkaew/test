
<?php
	header('Content-Type: application/json');

    $servername = "localhost";
    $username = "u348334018_gps";
    $password = "b]6dYFs&&=YV";
    $dbname = "u348334018_gps";

    // Create connection
    $objConnect = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($objConnect->connect_error) {
        die("Connection failed: " . $objConnect->connect_error);
    }


	mysqli_query($objConnect,"SET NAMES UTF8");

	
	/*$strSQL = " SELECT * FROM sensordata
				WHERE reading_time 
				BETWEEN DATE_SUB(NOW(), INTERVAL 1 DAY) AND NOW()  
	            ORDER BY reading_time DESC LIMIT 1";
	*/	
	
	
	
	//SELECT * FROM `sensordata` WHERE ID IN ( SELECT MAX(ID) FROM `sensordata` GROUP BY sensor );

	$strSQL = "SELECT * FROM `sensordata` WHERE ID IN ( SELECT MAX(ID) FROM `sensordata` GROUP BY sensor )";
	

	$objQuery = mysqli_query($objConnect, $strSQL);
	$resultArray = array();
	while($obResult = mysqli_fetch_array($objQuery))
	{
		array_push($resultArray,$obResult);
	}
	
	mysqli_close($objConnect);
	
	echo json_encode($resultArray);

?>
