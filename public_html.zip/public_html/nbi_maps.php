<?php
include('connect.php');

$sql_marker = "SELECT * FROM agency;";
$query_marker = mysqli_query($conn, $sql_marker);
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <!--<meta http-equiv="refresh" content="5" >-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>GPS Tracking</title>
    <link href="assets/bootstrap.min.css" rel="stylesheet">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


    <title>GPS-Tracking</title>

    <!-- Mobile Specific Meta
  ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png" />

    <!-- CSS
  ================================================== -->
    <!-- Themefisher Icon font -->
    <link rel="stylesheet" href="plugins/themefisher-font.v-2/style.css">
    <!-- bootstrap.min css -->
    <link rel="stylesheet" href="plugins/bootstrap/dist/css/bootstrap.min.css">
    <!-- Slick Carousel -->
    <link rel="stylesheet" href="plugins/slick-carousel/slick/slick.css">
    <link rel="stylesheet" href="plugins/slick-carousel/slick/slick-theme.css">
    <!-- Main Stylesheet -->
    <link rel="stylesheet" href="css/style.css">

    <!-- Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@100;200&display=swap" rel="stylesheet">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

    <style>
    body {
        font-family: 'Sarabun', sans-serif;
    }

    #map {
        width: 100%;
        height: 650px;
    }

    .datatable {
        margin-right: 25px;
        margin-left: 25px;
    }

    .scrollit {
        overflow: scroll;
        height: 650px;
    }
    </style>

</head>

<body onload="init();">
    <div id="preloader">
        <div class="preloader">
            <div class="sk-circle1 sk-child"></div>
            <div class="sk-circle2 sk-child"></div>
            <div class="sk-circle3 sk-child"></div>
            <div class="sk-circle4 sk-child"></div>
            <div class="sk-circle5 sk-child"></div>
            <div class="sk-circle6 sk-child"></div>
            <div class="sk-circle7 sk-child"></div>
            <div class="sk-circle8 sk-child"></div>
            <div class="sk-circle9 sk-child"></div>
            <div class="sk-circle10 sk-child"></div>
            <div class="sk-circle11 sk-child"></div>
            <div class="sk-circle12 sk-child"></div>
        </div>
    </div>
    <br>
    <div class="container">
        <section class="services section-xs" id="services">
            <div class="container">
                <div class="row">
                    <div class="col-md-8"><br>

                                <script>
                                
                                var iconImage = "http://gpstracking.landuselandcover.com/images/track-red.png";

                                function initMap() {
                                    var mapOptions = {
                                        center: {
                                            lat: 12.879759880237046,
                                            lng: 100.48821645268906
                                        },
                                        zoom: 6,
                                    }

                                    var maps = new google.maps.Map(document.getElementById("map"), mapOptions);

                                    var marker, info;
                                    


                                    $.getJSON("nbi_json.php", function(jsonObj) {
                                        $.each(jsonObj, function(i, item) {
                                            marker = new google.maps.Marker({
                                                position: new google.maps.LatLng(item
                                                    .lat_str,
                                                    item.lng_str),
                                                map: maps,
                                                title: item.sensor,
                                                icon: iconImage
                                            });


                                            info = new google.maps.InfoWindow();


                                            google.maps.event.addListener(marker, 'click', (
                                                function(
                                                    marker, i) {
                                                    return function() {
                                                        info.setContent(item.sensor);
                                                        info.open(maps, marker);
                                                    }

                                                })(marker, i));

                                        }); // loop
                                    });

                                }
                                </script>
                                <script
                                    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB0i77Mj0pOX0URlGv7Ska295R9ua0ifIk&callback=initMap"
                                    async defer></script>

                                <div id="map"></div>
                    </div>
                </div>
            </div>
        </section>
        <script src="plugins/jquery/dist/jquery.min.js"></script>
        <script src="plugins/bootstrap/dist/js/popper.min.js"></script>
        <script src="plugins/bootstrap/dist/js/bootstrap.min.js"></script>
        <script src="plugins/slick-carousel/slick/slick.min.js"></script>
        <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
        <script src="plugins/smooth-scroll/dist/js/smooth-scroll.min.js"></script>
        <script src="js/script.js"></script>
        <script src="assets/jquery.min.js"></script>
        <script src="assets/script.js"></script>
</body>

</html>