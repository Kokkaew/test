<?php
    require_once("config.php");
    $temp = $_GET['Temp'];
    $sql = "UPDATE temp SET temp = '$temp' WHERE id =1";
    $sql_query = mysql_query($sql);
    if ($sql_query) {
        echo "Complete";
    } else {
        echo "Error";
    }
?>