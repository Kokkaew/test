<?php
    $host = "localhost";    
    $user = "u348334018_gps";    
    $pass = "b]6dYFs&&=YV"";    
    $db = "u348334018_gps";    
    
    mysql_connect($host, $user, $pass) or die("Could not connect to database"); 
    mysql_select_db($db) or die("Could not connect to database"); 
    mysql_query("SET NAMES utf8")
?>