<?php
include('connect.php');

$sql_marker = "SELECT * FROM agency;";
$query_marker = mysqli_query($conn, $sql_marker);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <!--<meta http-equiv="refresh" content="5" >-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>GPS Tracking</title>
    <link href="assets/bootstrap.min.css" rel="stylesheet">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">


    <title>GPS-Tracking</title>

    <!-- Mobile Specific Meta
  ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.png" />

    <!-- CSS
  ================================================== -->
    <!-- Themefisher Icon font -->
    <link rel="stylesheet" href="plugins/themefisher-font.v-2/style.css">
    <!-- bootstrap.min css -->
    <link rel="stylesheet" href="plugins/bootstrap/dist/css/bootstrap.min.css">
    <!-- Slick Carousel -->
    <link rel="stylesheet" href="plugins/slick-carousel/slick/slick.css">
    <link rel="stylesheet" href="plugins/slick-carousel/slick/slick-theme.css">
    <!-- Main Stylesheet -->
    <link rel="stylesheet" href="css/style.css">

    <!-- Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Sarabun:wght@100;200&display=swap" rel="stylesheet">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>

    <style>
    body {
        font-family: 'Sarabun', sans-serif;
    }

    #map {
        width: 100%;
        height: 650px;
    }

    .datatable {
        margin-right: 25px;
        margin-left: 25px;
    }

    .scrollit {
        overflow: scroll;
        height: 650px;
    }

    .badge-padding {
        padding: 5px;
    }
    </style>

</head>

<body onload="init();">
    <div id="preloader">
        <div class="preloader">
            <div class="sk-circle1 sk-child"></div>
            <div class="sk-circle2 sk-child"></div>
            <div class="sk-circle3 sk-child"></div>
            <div class="sk-circle4 sk-child"></div>
            <div class="sk-circle5 sk-child"></div>
            <div class="sk-circle6 sk-child"></div>
            <div class="sk-circle7 sk-child"></div>
            <div class="sk-circle8 sk-child"></div>
            <div class="sk-circle9 sk-child"></div>
            <div class="sk-circle10 sk-child"></div>
            <div class="sk-circle11 sk-child"></div>
            <div class="sk-circle12 sk-child"></div>
        </div>
    </div>

    <section class="header  navigation">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <nav class="navbar navbar-expand-lg">
                        <a class="navbar-brand" href="index.html"><img src="images/kmutt-th.png" class="img-responsive"
                                alt=""></a>
                        <a class="navbar-brand" href="index.html"><img src="images/nrct-logo.png" class="img-responsive"
                                alt=""></a>
                        <a class="navbar-brand" href="index.html"><img src="images/department_of_health.png"
                                class="img-responsive" alt=""></a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse"
                            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class="tf-ion-android-menu"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ml-auto">
                                <li class="nav-item active">
                                    <a class="nav-link" href="index.php">หน้าแรก <span
                                            class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="about.php">ข้อมูลโครงการ</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="contact.php">ติดต่อเรา</a>
                                </li>
                            </ul>
                        </div>
                        <div class="topnav">
                            <div class="login-container">
                                <a href="login.php"><img src="images/login/sign-in.png" alt="logo"></a>
                            </div>
                        </div>
                    </nav>

                </div>
            </div>
        </div>
    </section>

    <br>
    <div class="container">
        <div class="container text-center">
            <div class="row">
                <div class="input-group">
                    <span class="input-group-text"><b>เลือกหน่วยงาน: </b></span>
                    <select id="mySelect" name="myselect" class="form-control" onchange="myFunction()">
                        <option value="0">ทั้งหมด</option>
                        <?php foreach ($query_marker as $value) { ?>
                        <option value="<?=$value['agency_id']?>"><?=$value['agency_name']?></option>
                        <?php } ?>
                    </select>
                    <!--<button type="button" class="btn btn-primary" onclick="selectValue()"> ค้นหา </button>-->
                </div>
            </div>
        </div>

        <br>

        <p id="demo"></p>

        <section class="services section-xs" id="services">
            <div class="container">
                <div class="row">
                    <div class="col-md-7">
                        <ul class="list-group">
                            <li class="list-group-item active" aria-current="true">แผนที่แสดงตำแหน่งรถ</li>
                            <li class="list-group-item">
                                <script>
                                function initMap() {
                                    var mapOptions = {
                                        center: {
                                            lat: 12.879759880237046,
                                            lng: 100.48821645268906
                                        },
                                        zoom: 6,
                                    }

                                    var maps = new google.maps.Map(document.getElementById("map"), mapOptions);

                                    var marker, info;
                                    var iconImage = "http://gpstracking.landuselandcover.com/images/track.png";

                                    $.getJSON("all_json.php", function(jsonObj) {
                                        $.each(jsonObj, function(i, item) {
                                            marker = new google.maps.Marker({
                                                position: new google.maps.LatLng(item
                                                    .lat_str,
                                                    item.lng_str),
                                                map: maps,
                                                title: item.sensor,
                                                icon: "http://gpstracking.landuselandcover.com/images/" +
                                                    item.icon
                                            });

                                            info = new google.maps.InfoWindow();

                                            google.maps.event.addListener(marker, 'click', (
                                                function(marker, i) {

                                                    return function() {
                                                        info.setContent(
                                                            "<div style = 'width:250px;min-height:40px'>" +
                                                            "<b>" + "หน่วยงาน: " +
                                                            "</b>" + item.agency +
                                                            "<br>" +
                                                            "<b>" + "ทะเบียนรถ: " +
                                                            "</b>" + item.sensor +
                                                            "<br>" +
                                                            "<b>" + "สถานะ: " + "</b>" +
                                                            item.statuscar + "</div>");

                                                        info.open(maps, marker);
                                                    }
                                                })(marker, i));

                                        }); // loop

                                    });

                                }

                                function myFunction(x) {
                                    var x = document.getElementById("mySelect").value;
                                    //document.getElementById("demo").innerHTML = "You selected: " + x;

                                    if (x == 1) {
                                        var mapOptions = {
                                            center: {
                                                lat: 12.879759880237046,
                                                lng: 100.48821645268906
                                            },
                                            zoom: 6,
                                        }

                                        var maps = new google.maps.Map(document.getElementById("map"), mapOptions);

                                        var marker, info;
                                        var iconImage = "http://gpstracking.landuselandcover.com/images/track.png";

                                        $.getJSON("pct_json.php", function(jsonObj) {
                                            $.each(jsonObj, function(i, item) {
                                                marker = new google.maps.Marker({
                                                    position: new google.maps.LatLng(item
                                                        .lat_str,
                                                        item.lng_str),
                                                    map: maps,
                                                    title: item.sensor,
                                                    icon: "http://gpstracking.landuselandcover.com/images/" +
                                                        item.icon
                                                });

                                                info = new google.maps.InfoWindow();

                                                google.maps.event.addListener(marker, 'click', (
                                                    function(marker, i) {
                                                        return function() {
                                                            info.setContent(
                                                                "<div style = 'width:250px;min-height:40px'>" +
                                                                "<b>" + "หน่วยงาน: " +
                                                                "</b>" + item.agency +
                                                                "<br>" +
                                                                "<b>" + "ทะเบียนรถ: " +
                                                                "</b>" + item.sensor +
                                                                "<br>" +
                                                                "<b>" + "สถานะ: " +
                                                                "</b>" + item
                                                                .statuscar + "</div>");

                                                            info.open(maps, marker);
                                                        }
                                                    })(marker, i));

                                            }); // loop
                                        });
                                    } else if (x == 2) {
                                        var mapOptions = {
                                            center: {
                                                lat: 12.879759880237046,
                                                lng: 100.48821645268906
                                            },
                                            zoom: 6,
                                        }

                                        var maps = new google.maps.Map(document.getElementById("map"), mapOptions);

                                        var marker, info;
                                        var iconImage = "http://gpstracking.landuselandcover.com/images/track.png";

                                        $.getJSON("nbi_json.php", function(jsonObj) {
                                            $.each(jsonObj, function(i, item) {
                                                marker = new google.maps.Marker({
                                                    position: new google.maps.LatLng(item
                                                        .lat_str,
                                                        item.lng_str),
                                                    map: maps,
                                                    title: item.sensor,
                                                    icon: "http://gpstracking.landuselandcover.com/images/" +
                                                        item.icon
                                                });

                                                info = new google.maps.InfoWindow();

                                                google.maps.event.addListener(marker, 'click', (
                                                    function(marker, i) {
                                                        return function() {
                                                            info.setContent(
                                                                "<div style = 'width:250px;min-height:40px'>" +
                                                                "<b>" + "หน่วยงาน: " +
                                                                "</b>" + item.agency +
                                                                "<br>" +
                                                                "<b>" + "ทะเบียนรถ: " +
                                                                "</b>" + item.sensor +
                                                                "<br>" +
                                                                "<b>" + "สถานะ: " +
                                                                "</b>" + item
                                                                .statuscar + "</div>");

                                                            info.open(maps, marker);
                                                        }
                                                    })(marker, i));

                                            }); // loop
                                        });
                                    } else {
                                        var mapOptions = {
                                            center: {
                                                lat: 12.879759880237046,
                                                lng: 100.48821645268906
                                            },
                                            zoom: 6,
                                        }

                                        var maps = new google.maps.Map(document.getElementById("map"), mapOptions);

                                        var marker, info;
                                        var iconImage = "http://gpstracking.landuselandcover.com/images/track.png";

                                        $.getJSON("all_json.php", function(jsonObj) {
                                            $.each(jsonObj, function(i, item) {
                                                marker = new google.maps.Marker({
                                                    position: new google.maps.LatLng(item
                                                        .lat_str,
                                                        item.lng_str),
                                                    map: maps,
                                                    title: item.sensor,
                                                    icon: "http://gpstracking.landuselandcover.com/images/" +
                                                        item.icon
                                                });

                                                info = new google.maps.InfoWindow();

                                                google.maps.event.addListener(marker, 'click', (
                                                    function(marker, i) {
                                                        return function() {
                                                            info.setContent(
                                                                "<div style = 'width:250px;min-height:40px'>" +
                                                                "<b>" + "หน่วยงาน: " +
                                                                "</b>" + item.agency +
                                                                "<br>" +
                                                                "<b>" + "ทะเบียนรถ: " +
                                                                "</b>" + item.sensor +
                                                                "<br>" +
                                                                "<b>" + "สถานะ: " +
                                                                "</b>" +
                                                                item.statuscar +
                                                                "</div>");

                                                            info.open(maps, marker);
                                                        }
                                                    })(marker, i));


                                                //Zoom to 7 when clicked on marker
                                                google.maps.event.addListener(marker, 'click',
                                                    function() {
                                                        map.setZoom(9);
                                                        map.setCenter(marker.getPosition());
                                                    });

                                            }); // loop
                                        });
                                    }

                                }
                                </script>
                                <script
                                    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB0i77Mj0pOX0URlGv7Ska295R9ua0ifIk&callback=initMap"
                                    async defer></script>
                                <div id="map"></div>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-5">
                        <!--<div class="row scrollit" id="autostatus">-->
                        <ul class="list-group">
                            <li class="list-group-item active" aria-current="true">สถานะของรถที่ออกปฏิบัติงาน <span
                                    class="badge badge-light badge-padding"> ครั้งล่าสุด </span></li>
                            <li class="list-group-item">
                                <div class="row scrollit" id="autostatus">
                                    <script>
                                    $(document).ready(function() {
                                        setInterval(function() {
                                            $("#autostatus").load("status.php");
                                            refresh();
                                        }, 10000);
                                    });
                                    </script>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <script src="plugins/jquery/dist/jquery.min.js"></script>
        <script src="plugins/bootstrap/dist/js/popper.min.js"></script>
        <script src="plugins/bootstrap/dist/js/bootstrap.min.js"></script>
        <script src="plugins/slick-carousel/slick/slick.min.js"></script>
        <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
        <script src="plugins/smooth-scroll/dist/js/smooth-scroll.min.js"></script>
        <script src="js/script.js"></script>
        <script src="assets/jquery.min.js"></script>
        <script src="assets/script.js"></script>
</body>

</html>