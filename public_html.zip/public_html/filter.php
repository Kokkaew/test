<?php
	require'connect.php';
	if(ISSET($_POST['filter'])){
		$category=$_POST['statuscar'];
		
		$query=mysqli_query($conn, "SELECT * FROM `sensordata` WHERE `statuscar`='$category' LIMIT 5") or die(mysqli_error());
		while($fetch=mysqli_fetch_array($query)){
			echo"
            <tr>
                <td>".$fetch['reading_time']."</td>
                <td>".$fetch['sensor']."</td>
                <td>".$fetch['lat_str']."</td>
                <td>".$fetch['lng_str']."</td>
                <td>".$fetch['speedcar']."</td>
                <td>".$fetch['statuscar']."</td>
            </tr>";
		}
	}else if(ISSET($_POST['reset'])){
		$query=mysqli_query($conn, "SELECT * FROM `sensordata` LIMIT 2") or die(mysqli_error());
		while($fetch=mysqli_fetch_array($query)){
			echo"
            <tr>
                <td>".$fetch['reading_time']."</td>
                <td>".$fetch['sensor']."</td>
                <td>".$fetch['lat_str']."</td>
                <td>".$fetch['lng_str']."</td>
                <td>".$fetch['speedcar']."</td>
                <td>".$fetch['statuscar']."</td>
            </tr>";
		}
	}else{
		$query=mysqli_query($conn, "SELECT * FROM `sensordata` LIMIT 10") or die(mysqli_error());
		while($fetch=mysqli_fetch_array($query)){
			echo"
            <tr>
                <td>".$fetch['reading_time']."</td>
                <td>".$fetch['sensor']."</td>
                <td>".$fetch['lat_str']."</td>
                <td>".$fetch['lng_str']."</td>
                <td>".$fetch['speedcar']."</td>
                <td>".$fetch['statuscar']."</td>
            </tr>";
		}
	}
?>